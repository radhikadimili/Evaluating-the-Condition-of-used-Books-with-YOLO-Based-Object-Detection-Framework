# Damaged Books > 2023-10-16 12:33am
https://universe.roboflow.com/atcom21-gmail-com/damaged-books

Provided by a Roboflow user
License: CC BY 4.0

